//  File:   Interrupt_ISRs.c
//  Date:   02/24/2018
//  Name:   Mark Schuster
//  Class:  EEE4511C (DSP)

#include "msLib.h"


Uint16 audioState;
interrupt void timer1Isr()
{
    CpuTimer1Regs.TCR.bit.TIF = 1;
    return;
}

/* ---PART 1's ISR ---
interrupt void audioIsr(void)
{
    enum{REC_MIX_NOT_DONE,REC_DONE, MIX_DONE,};
    static Uint16 recState = REC;
    static Uint32 currentSramIndex = 0;

    if( audioState == REC )
    {

        if(currentSramIndex <= SRAM_END && recState != REC_DONE)
            sram[currentSramIndex++] = McbspbRegs.DRR2.all;
        else
        {
            setLEDS(0x01);
            recState = REC_DONE;
            currentSramIndex = 0;
            Uint16 temp = McbspbRegs.DRR1.all;
            temp = McbspbRegs.DRR2.all;
        }
        int16 temp = McbspbRegs.DRR1.all;
        McbspbRegs.DXR1.all = 0x00;
        McbspbRegs.DXR2.all = 0x00;
    }

    else if( audioState == MIX  )
    {
        if(currentSramIndex <= SRAM_END && recState != MIX_DONE )
            sram[currentSramIndex++] = ((int16)sram[currentSramIndex])/2 + ((int16)McbspbRegs.DRR2.all)/2;
        else
        {
            setLEDS(0x01);
            recState = MIX_DONE;
            currentSramIndex = 0;
            Uint16 temp = McbspbRegs.DRR1.all;
            temp = McbspbRegs.DRR2.all;
        }
        int16 temp = McbspbRegs.DRR1.all;
        McbspbRegs.DXR1.all = 0x00;
        McbspbRegs.DXR2.all = 0x00;
    }
    else if( audioState == PLAY  )
    {
        if(currentSramIndex <= SRAM_END)
        {
            Uint16 temp = McbspbRegs.DRR1.all;
            temp = McbspbRegs.DRR2.all;
            McbspbRegs.DXR2.all = sram[currentSramIndex++];
        }
        else
        {
            Uint16 temp = McbspbRegs.DRR1.all;
            temp = McbspbRegs.DRR2.all;
            McbspbRegs.DXR2.all = 0x00;
            currentSramIndex = 0x00;
        }
        McbspbRegs.DXR1.all = 0x00;
        recState = REC_MIX_NOT_DONE;
        setLEDS(0x00);
    }

    else if( audioState == IDLE )
    {
        Uint16 temp = McbspbRegs.DRR1.all;
        temp = McbspbRegs.DRR2.all;
        McbspbRegs.DXR1.all = 0x00;
        McbspbRegs.DXR2.all = 0x00;
        recState = REC_MIX_NOT_DONE;
        currentSramIndex = 0x00;
        setLEDS(0x00);
    }

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;
}
*/

/* ---PART 2's ISR --- */
interrupt void audioIsr(void)
{
    GpioDataRegs.GPATOGGLE.bit.GPIO14 = 1;
    McbspbRegs.DXR1.all = McbspbRegs.DRR1.all;
    McbspbRegs.DXR2.all = McbspbRegs.DRR2.all;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;
}


/* ---PART 3's ISR ---
interrupt void audioIsr(void)
{
    static Uint32 currentSramIndex = 0;

    if( audioState == REC_48 )
    {

        if(currentSramIndex <= SRAM_END)
        {    --- PART3.2 ---
            if(currentSramIndex == 0x00)
                sram[currentSramIndex] = McbspbRegs.DRR2.all;
            else
            {
                sram[currentSramIndex] = McbspbRegs.DRR2.all;
                sram[currentSramIndex-1] = (int16)sram[currentSramIndex-2]/2 + (int16)sram[currentSramIndex]/2;
            }
            currentSramIndex += 2;

            --- PART3.3 ---
            static Uint16 state = 0;
            if(state < 4)
            { Uint16 temp = McbspbRegs.DRR2.all; }
            else
            {
                sram[currentSramIndex++] = McbspbRegs.DRR2.all;
                state = 0;
            }

            state++;
            *//*
        }
        else
        {
            setLEDS(0x01);
            audioState = PLAY_32;
            currentSramIndex = 0;
            Uint16 temp = McbspbRegs.DRR1.all;
            temp = McbspbRegs.DRR2.all;
        }
        int16 temp = McbspbRegs.DRR1.all;
        McbspbRegs.DXR1.all = 0x00;
        McbspbRegs.DXR2.all = 0x00;
    }
    else if( audioState == PLAY_32 || audioState == PLAY_8 || audioState == PLAY_48)
    {
        if(currentSramIndex <= SRAM_END)
        {
            Uint16 temp = McbspbRegs.DRR1.all;
            temp = McbspbRegs.DRR2.all;
            McbspbRegs.DXR2.all = sram[currentSramIndex++];

        }
        else
        {
            Uint16 temp = McbspbRegs.DRR1.all;
            temp = McbspbRegs.DRR2.all;
            McbspbRegs.DXR2.all = 0x00;
            currentSramIndex = 0x00;
        }
        McbspbRegs.DXR1.all = 0x00;
    }
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;
}
*/

#define ALPHA 0.3

/* ---PART 4.1's ISR ---
interrupt void audioIsr(void)
{
    static Uint32 currentSramIndex = 0;

    if(currentSramIndex <= SRAM_END)
    {
        sram[currentSramIndex++] = McbspbRegs.DRR2.all;
        int32 echoIndex = currentSramIndex + (getSwitches()*480);
        if(echoIndex < 0)
            echoIndex = SRAM_END + echoIndex;
        float f = (1-ALPHA)*(int16)sram[echoIndex] + ALPHA*(int16)sram[currentSramIndex];
        McbspbRegs.DXR2.all = (int16)f;
    }
    else
    {
        currentSramIndex = 0;
        McbspbRegs.DXR2.all = sram[currentSramIndex];
    }


    int16 temp = McbspbRegs.DRR1.all;
    McbspbRegs.DXR1.all = 0x00;


    PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;
}
*/

/* ---PART 4.2's ISR ---
interrupt void audioIsr(void)
{
    static Uint32 currentSramIndex = 0;

    if(currentSramIndex < (SRAM_END+1)/2)
    {
        int32 echoIndex = currentSramIndex - (getSwitches()*12000);
        if(echoIndex < 0)
            echoIndex = (SRAM_END+1)/2 - echoIndex;
        sram[currentSramIndex] = McbspbRegs.DRR2.all;
        float f = (1-ALPHA)*(int16)sram[currentSramIndex] + ALPHA*(int16)sram[echoIndex + (SRAM_END+1)/2];
        sram[currentSramIndex + (SRAM_END+1)/2] = (int16)f;
        McbspbRegs.DXR2.all = sram[currentSramIndex + (SRAM_END+1)/2];
        currentSramIndex++;
    }
    else
    {
        currentSramIndex = 0;
        McbspbRegs.DXR2.all = sram[currentSramIndex];
    }


    int16 temp = McbspbRegs.DRR1.all;
    McbspbRegs.DXR1.all = 0x00;


    PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;
}
*/
