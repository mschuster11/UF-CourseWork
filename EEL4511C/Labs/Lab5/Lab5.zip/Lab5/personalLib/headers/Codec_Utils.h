//  File:   Codec_Utils.h
//  Date:   02/24/2018
//  Name:   Mark Schuster
//  Class:  EEE4511C (DSP)

#ifndef CODECUTILS_H_
#define CODECUTILS_H_

extern interrupt void codecIsr();
void initCodec(void);

#endif
