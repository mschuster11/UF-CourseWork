//  File:   LEDs_switches_Utils.h
//  Date:   02/24/2018
//  Name:   Mark Schuster
//  Class:  EEE4511C (DSP)

#ifndef LEDSSWITCHESUTILS_H_
#define LEDSSWITCHESUTILS_H_

void initLEDSAndSwitches(void);
void setLEDS(Uint16);
Uint16 getSwitches(void);

#endif
