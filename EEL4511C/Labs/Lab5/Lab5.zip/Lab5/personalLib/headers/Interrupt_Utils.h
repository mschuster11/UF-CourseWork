//  File:   Interrupt_Utils.h
//  Date:   02/24/2018
//  Name:   Mark Schuster
//  Class:  EEE4511C (DSP)

#ifndef INTERRUPTUTILS_H_
#define INTERRUPTUTILS_H_

void initInterrupts(void);

#endif
