//  File:   I2C_LCD_Utils.h
//  Date:   02/24/2018
//  Name:   Mark Schuster
//  Class:  EEE4511C (DSP)

#ifndef ADCUTILS_H_
#define ADCUTILS_H_

void initADC(void);

#endif
