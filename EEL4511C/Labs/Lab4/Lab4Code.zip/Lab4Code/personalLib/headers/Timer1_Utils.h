//  File:   Timer1_Utils.h
//  Date:   02/24/2018
//  Name:   Mark Schuster
//  Class:  EEE4511C (DSP)

#ifndef TIMER1UTILS_H_
#define TIMER1UTILS_H_

extern interrupt void timer1Isr();
void initTimer1(void);

#endif
